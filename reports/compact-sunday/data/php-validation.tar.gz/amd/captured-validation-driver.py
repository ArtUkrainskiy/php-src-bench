from pathlib import Path
import json
import os
import subprocess

root = Path('/tmp/php-compact-sunday-20261031')
builds = root / 'builds'
tree = builds / 'compact-asan'
rows = []
for name in ['compact-base-gcc15', 'compact-head-gcc15', 'compact-base-clang21', 'compact-head-clang21', 'compact-asan']:
    php = builds / name / 'sapi/cli/php'
    asan = name == 'compact-asan'
    env = {**os.environ, 'TEST_PHP_EXECUTABLE': str(php), 'REPORT_EXIT_STATUS': '1'}
    if asan: env['USE_ZEND_ALLOC'] = '0'
    cmd = ['taskset', '-c', '0-13', str(php), '-n', str(tree / 'run-tests.php'), '-q', '-j8',
           '-p', str(php), '--offline', *(['--asan'] if asan else []), 'ext/standard/tests/strings']
    with (root / 'logs' / ('phpt-' + name + '.log')).open('w') as log:
        result = subprocess.run(cmd, cwd=tree, env=env, stdout=log, stderr=subprocess.STDOUT)
    rows.append(dict(name=name, returncode=result.returncode, command=cmd))
    (root / 'php-validation.json').write_text(json.dumps(rows, indent=2) + '\n')
    assert result.returncode == 0, name
    print(name, 'PASS', flush=True)
(root / 'validation-complete').write_text('PASS\n')
