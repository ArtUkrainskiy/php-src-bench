from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
src = Path('/home/artem/CLionProjects/php-src-wt/strpos-compact-sunday-pr')
verify = root.parents[2] / 'reports/substr-adaptive-search/verify'
adapter = (verify / 'standalone.c').read_text()
prefix = adapter[:adapter.index('#define ZEND_MEMNSTR_GRAM_SAMPLE_SIZE')]
inline_start = adapter.rfind('static', 0, adapter.index('\nzend_memnstr('))
inline = adapter[inline_start:adapter.index('typedef const unsigned char *(*finder)')]
current = (src / 'Zend/zend_operators.c').read_text()
base = subprocess.check_output(['git', '-C', str(src), 'show', 'cf1b5771a76:Zend/zend_operators.c'], text=True)
def core(text):
    return text[text.index('static zend_always_inline void zend_memnstr_ex_pre('):text.index('ZEND_API const char* ZEND_FASTCALL zend_memnrstr_ex(')]
baseline = core(base).replace('zend_memnstr_ex_pre', 'base_pre').replace('zend_memnstr_ex', 'base_ex')
base_inline = inline.replace('zend_memnstr_ex', 'base_ex').replace('zend_memnstr(', 'base_memnstr(')
wrappers = '''
typedef const unsigned char *(*finder)(const unsigned char *, size_t, const unsigned char *, size_t);
static const unsigned char *zend_candidate_find(const unsigned char *h, size_t hl, const unsigned char *n, size_t nl) {
    return (const unsigned char *)zend_memnstr((const char *)h, (const char *)n, nl, (const char *)h + hl);
}
static const unsigned char *base_find(const unsigned char *h, size_t hl, const unsigned char *n, size_t nl) {
    return (const unsigned char *)base_memnstr((const char *)h, (const char *)n, nl, (const char *)h + hl);
}
'''
validator = (verify / 'validate.c').read_text().replace('zend_candidate_find, zend_pair_find, zend_twoway_find, zend_gram_find', 'zend_candidate_find, base_find')
validator = validator.replace('size_t count = argc', '''unsigned char default_h[1086], default_n[31];
    memset(default_h, 'z', sizeof default_h); memset(default_n, 'a', sizeof default_n);
    memcpy(default_h + 1055, default_n, sizeof default_n);
    check(default_h, sizeof default_h, default_n, sizeof default_n);
    size_t count = argc''').replace('all candidate/pair/gram4/Two-Way checks passed', 'candidate/base/libc checks passed')
report = dict(base='cf1b5771a76a81b455a8677446daf9c46e1781be', head='8d7babbc364ffcf28dac9777ce807edc9adbb534',
              source_sha256=hashlib.sha256(core(current).encode()).hexdigest(), seed=20261030, runs=[])
for cc in ['gcc', 'clang']:
    for mutation in ['none', 'default-shift-too-large', 'omit-last-position']:
        body = core(current)
        start = body.index('static zend_never_inline const char* ZEND_FASTCALL zend_memnstr_sunday_short(')
        if mutation == 'default-shift-too-large':
            body = body[:start] + body[start:].replace('(unsigned char)(needle_len + 1)', '(unsigned char)(needle_len + 2)', 1)
        if mutation == 'omit-last-position':
            body = body[:start] + body[start:].replace('while (p <= end)', 'while (p < end)', 1)
        out = root / ('validate-' + cc + '-' + mutation)
        out.mkdir(exist_ok=True)
        (out / 'standalone.c').write_text(prefix + baseline + base_inline + body + inline + wrappers)
        (out / 'validate.c').write_text(validator)
        binary = out / 'check'
        with (out / 'build.log').open('w') as log:
            subprocess.run([cc, '-std=gnu11', '-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
                            str(out / 'validate.c'), '-o', str(binary)], stdout=log, stderr=subprocess.STDOUT, check=True)
        process = subprocess.run([str(binary), '20000'], capture_output=True, text=True, timeout=120)
        (out / 'run.log').write_text(process.stdout + process.stderr)
        assert process.returncode == (0 if mutation == 'none' else 3), (cc, mutation, process.stderr)
        if mutation == 'none': assert not process.stderr, process.stderr
        report['runs'].append(dict(compiler=cc, version=subprocess.check_output([cc, '--version'], text=True).splitlines()[0],
                                   mutation=mutation, returncode=process.returncode, output=process.stdout + process.stderr))
        (root / 'c-validation.json').write_text(json.dumps(report, indent=2) + '\n')
        print(cc, mutation, 'PASS', flush=True)
