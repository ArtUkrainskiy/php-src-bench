#!/usr/bin/env python3
"""Full-PHP reproduction of the repeated-prefix review cases."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--bench-root', type=Path, required=True)
p.add_argument('--builds', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--cpu', type=int, required=True)
p.add_argument('--orchestrator', type=int, required=True)
p.add_argument('--smoke', action='store_true')
a = p.parse_args()
root = Path(__file__).resolve().parent
a.out.mkdir(parents=True, exist_ok=True)
runs = a.out / 'runs'; runs.mkdir(exist_ok=True)
compilers = ['gcc15']
reference = json.loads((root / 'reference-builds.json').read_text())
fingerprints = {}
for cc in compilers:
    baseline = json.loads((a.builds / ('compact-base-' + cc) / '.bench-build.json').read_text())
    for variant, commit in [('base', 'cf1b5771a76a81b455a8677446daf9c46e1781be'), ('head', '8d7babbc364ffcf28dac9777ce807edc9adbb534')]:
        name = 'compact-' + variant + '-' + cc
        folder = a.builds / name
        metadata = json.loads((folder / '.bench-build.json').read_text())
        assert metadata['commit'] == commit and not metadata['debug'] and not metadata['snapshot']
        for field in ['cc', 'configure', 'cflags_user', 'ldflags', 'profile']:
            assert metadata[field] == baseline[field]
        digest = hashlib.sha256((folder / 'sapi/cli/php').read_bytes()).hexdigest()
        assert digest == reference[name]['sha256'], name
        fingerprints[name] = dict(commit=commit, sha256=digest, metadata=metadata)
(a.out / 'builds.json').write_text(json.dumps(fingerprints, indent=2) + '\n')
env = {**os.environ, 'BENCH_BUILDS': str(a.builds), 'BENCH_RESULTS': str(runs),
       'BENCH_PHP': str(a.builds / 'compact-base-clang21/sapi/cli/php'), 'NO_COLOR': '1'}
bench = str(a.bench_root / 'bench')
suite = str(root / 'suite.php')

def run(cc, length, tag, aa=False):
    target = a.out / (tag + '-' + cc + '.json')
    if target.exists():
        return
    command = ['taskset', '-c', str(a.orchestrator), bench, 'run', suite,
        '--a', 'compact-base-' + cc, '--b', ('compact-base-' if aa else 'compact-head-') + cc,
        '--cpu', str(a.cpu), '--filter', '^' + re.escape(f'strpos/prefix/{length} @ prefix-4096') + '$',
        '--rounds', '1', '--samples', '2' if a.smoke else '10',
        '--target-ms', '10' if a.smoke else '1000', '--warmup-ms', '10' if a.smoke else '3000',
        '--wait-idle', '30']
    before = set(runs.glob('*.json'))
    log = target.with_suffix('.log')
    print('START', tag, cc, flush=True)
    with log.open('w') as output:
        subprocess.run(command, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=100, check=True)
    added = set(runs.glob('*.json')) - before
    assert len(added) == 1
    target.write_bytes(added.pop().read_bytes())
    data = json.loads(target.read_text())
    case = next(iter(data['cases'].values()))
    x, y = (case['sides'][side] for side in ['A', 'B'])
    assert x['input_hash'] == y['input_hash'] and x['output_hash'] == y['output_hash']
    ax, bx = [statistics.median(r['rounds'][0]) - statistics.median(r['loop_ns']) for r in [x, y]]
    disturbed = 'measuring anyway' in log.read_text()
    print('DONE', tag, cc, f'{ax/1000:.4f} -> {bx/1000:.4f} us, {100*(bx/ax-1):+.2f}%',
        'IDLE_TIMEOUT' if disturbed else '', flush=True)

run('gcc15', 64, 'prefix-64')
run('gcc15', 64, 'aa-after', True)
(a.out / 'complete').write_text('PASS\n')
