
/tmp/php-compact-sunday-20261031/builds/compact-base-gcc15/sapi/cli/php:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

000000000074b0f0 <zend_memnstr_ex>:
  74b0f0:	endbr64
  74b0f4:	sub    $0x418,%rsp
  74b0fb:	mov    %fs:0x28,%rax
  74b104:	mov    %rax,0x408(%rsp)
  74b10c:	xor    %eax,%eax
  74b10e:	test   %rdx,%rdx
  74b111:	je     74b200 <zend_memnstr_ex+0x110>
  74b117:	mov    %rcx,%rax
  74b11a:	mov    %rcx,%r8
  74b11d:	sub    %rdi,%rax
  74b120:	cmp    %rdx,%rax
  74b123:	jb     74b200 <zend_memnstr_ex+0x110>
  74b129:	lea    0x1(%rdx),%eax
  74b12c:	lea    0x400(%rsp),%rcx
  74b134:	movd   %eax,%xmm0
  74b138:	mov    %rsp,%rax
  74b13b:	pshufd $0x0,%xmm0,%xmm0
  74b140:	movaps %xmm0,(%rax)
  74b143:	add    $0x20,%rax
  74b147:	movaps %xmm0,-0x10(%rax)
  74b14b:	cmp    %rax,%rcx
  74b14e:	jne    74b140 <zend_memnstr_ex+0x50>
  74b150:	mov    %rsi,%rax
  74b153:	lea    (%rsi,%rdx,1),%r11
  74b157:	lea    (%rdx,%rsi,1),%r10d
  74b15b:	nopl   0x0(%rax,%rax,1)
  74b160:	movzbl (%rax),%ecx
  74b163:	mov    %r10d,%r9d
  74b166:	sub    %eax,%r9d
  74b169:	add    $0x1,%rax
  74b16d:	mov    %r9d,(%rsp,%rcx,4)
  74b171:	cmp    %r11,%rax
  74b174:	jne    74b160 <zend_memnstr_ex+0x70>
  74b176:	mov    %r8,%rcx
  74b179:	sub    %rdx,%rcx
  74b17c:	cmp    %rdi,%rcx
  74b17f:	jb     74b200 <zend_memnstr_ex+0x110>
  74b181:	nopl   0x0(%rax)
  74b185:	data16 cs nopw 0x0(%rax,%rax,1)
  74b190:	xor    %eax,%eax
  74b192:	nopl   (%rax)
  74b195:	data16 cs nopw 0x0(%rax,%rax,1)
  74b1a0:	movzbl (%rdi,%rax,1),%r8d
  74b1a5:	cmp    %r8b,(%rsi,%rax,1)
  74b1a9:	jne    74b1d8 <zend_memnstr_ex+0xe8>
  74b1ab:	add    $0x1,%rax
  74b1af:	cmp    %rax,%rdx
  74b1b2:	jne    74b1a0 <zend_memnstr_ex+0xb0>
  74b1b4:	mov    0x408(%rsp),%rax
  74b1bc:	sub    %fs:0x28,%rax
  74b1c5:	jne    74b204 <zend_memnstr_ex+0x114>
  74b1c7:	mov    %rdi,%rax
  74b1ca:	add    $0x418,%rsp
  74b1d1:	ret
  74b1d2:	nopw   0x0(%rax,%rax,1)
  74b1d8:	cmp    %rax,%rdx
  74b1db:	je     74b1b4 <zend_memnstr_ex+0xc4>
  74b1dd:	cmp    %rdi,%rcx
  74b1e0:	je     74b200 <zend_memnstr_ex+0x110>
  74b1e2:	movzbl (%rdi,%rdx,1),%eax
  74b1e6:	mov    (%rsp,%rax,4),%eax
  74b1e9:	add    %rax,%rdi
  74b1ec:	cmp    %rdi,%rcx
  74b1ef:	jae    74b190 <zend_memnstr_ex+0xa0>
  74b1f1:	nopl   0x0(%rax)
  74b1f5:	data16 cs nopw 0x0(%rax,%rax,1)
  74b200:	xor    %edi,%edi
  74b202:	jmp    74b1b4 <zend_memnstr_ex+0xc4>
  74b204:	call   202080 <__stack_chk_fail@plt>

Disassembly of section .remap_stub:

Disassembly of section .fini:
