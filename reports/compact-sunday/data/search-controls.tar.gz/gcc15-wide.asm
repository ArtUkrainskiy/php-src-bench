
/tmp/php-compact-sunday-20261031/builds/compact-head-gcc15/sapi/cli/php:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

00000000007436c0 <zend_memnstr_sunday>:
  7436c0:	sub    $0x418,%rsp
  7436c7:	mov    %fs:0x28,%rax
  7436d0:	mov    %rax,0x408(%rsp)
  7436d8:	xor    %eax,%eax
  7436da:	test   %rdx,%rdx
  7436dd:	je     7437e0 <zend_memnstr_sunday+0x120>
  7436e3:	mov    %rcx,%rax
  7436e6:	mov    %rcx,%r8
  7436e9:	sub    %rdi,%rax
  7436ec:	cmp    %rdx,%rax
  7436ef:	jb     7437e0 <zend_memnstr_sunday+0x120>
  7436f5:	lea    0x1(%rdx),%eax
  7436f8:	lea    0x400(%rsp),%rcx
  743700:	movd   %eax,%xmm0
  743704:	mov    %rsp,%rax
  743707:	pshufd $0x0,%xmm0,%xmm0
  74370c:	nopl   0x0(%rax)
  743710:	movaps %xmm0,(%rax)
  743713:	add    $0x20,%rax
  743717:	movaps %xmm0,-0x10(%rax)
  74371b:	cmp    %rax,%rcx
  74371e:	jne    743710 <zend_memnstr_sunday+0x50>
  743720:	mov    %rsi,%rax
  743723:	lea    (%rsi,%rdx,1),%r11
  743727:	lea    (%rdx,%rsi,1),%r10d
  74372b:	cs nopw 0x0(%rax,%rax,1)
  743735:	data16 cs nopw 0x0(%rax,%rax,1)
  743740:	movzbl (%rax),%ecx
  743743:	mov    %r10d,%r9d
  743746:	sub    %eax,%r9d
  743749:	add    $0x1,%rax
  74374d:	mov    %r9d,(%rsp,%rcx,4)
  743751:	cmp    %r11,%rax
  743754:	jne    743740 <zend_memnstr_sunday+0x80>
  743756:	mov    %r8,%rcx
  743759:	sub    %rdx,%rcx
  74375c:	cmp    %rdi,%rcx
  74375f:	jb     7437e0 <zend_memnstr_sunday+0x120>
  743761:	nopl   0x0(%rax)
  743765:	data16 cs nopw 0x0(%rax,%rax,1)
  743770:	xor    %eax,%eax
  743772:	nopl   (%rax)
  743775:	data16 cs nopw 0x0(%rax,%rax,1)
  743780:	movzbl (%rdi,%rax,1),%r8d
  743785:	cmp    %r8b,(%rsi,%rax,1)
  743789:	jne    7437b8 <zend_memnstr_sunday+0xf8>
  74378b:	add    $0x1,%rax
  74378f:	cmp    %rax,%rdx
  743792:	jne    743780 <zend_memnstr_sunday+0xc0>
  743794:	mov    0x408(%rsp),%rax
  74379c:	sub    %fs:0x28,%rax
  7437a5:	jne    7437e4 <zend_memnstr_sunday+0x124>
  7437a7:	mov    %rdi,%rax
  7437aa:	add    $0x418,%rsp
  7437b1:	ret
  7437b2:	nopw   0x0(%rax,%rax,1)
  7437b8:	cmp    %rax,%rdx
  7437bb:	je     743794 <zend_memnstr_sunday+0xd4>
  7437bd:	cmp    %rdi,%rcx
  7437c0:	je     7437e0 <zend_memnstr_sunday+0x120>
  7437c2:	movzbl (%rdi,%rdx,1),%eax
  7437c6:	mov    (%rsp,%rax,4),%eax
  7437c9:	add    %rax,%rdi
  7437cc:	cmp    %rdi,%rcx
  7437cf:	jae    743770 <zend_memnstr_sunday+0xb0>
  7437d1:	nopl   0x0(%rax)
  7437d5:	data16 cs nopw 0x0(%rax,%rax,1)
  7437e0:	xor    %edi,%edi
  7437e2:	jmp    743794 <zend_memnstr_sunday+0xd4>
  7437e4:	call   202080 <__stack_chk_fail@plt>

Disassembly of section .remap_stub:

Disassembly of section .fini:
