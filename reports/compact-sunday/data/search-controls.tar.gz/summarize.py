#!/usr/bin/env python3
"""Render the predeclared full-PHP search-control matrix from native data."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import statistics as st

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--data', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--partial', action='store_true')
a = p.parse_args()
a.out.mkdir(parents=True, exist_ok=True)
manifest = json.loads((a.data / 'cases.json').read_text())
selected = json.loads((a.data / 'timed-cases.json').read_text())
by_name = {c['name']: c for c in manifest['cases']}
counter = {}
counter_path = a.data / 'amd-matrix/cycles.json'
if counter_path.exists():
    data = json.loads(counter_path.read_text())
    assert data['complete'] and len(data['cases']) == 58
    assert len(data['rows']) == 2320 and not data['warnings'] and not data['marks']
    counted = defaultdict(lambda: defaultdict(list))
    for group, side, key, cyc, ins, empty_cyc, empty_ins in data['rows']:
        n = data['cases'][key]['n']
        counted[group, key][side].append(((cyc - empty_cyc) / n, (ins - empty_ins) / n))
    for (group, key), values in counted.items():
        x, y = values['a'], values['b']
        assert len(x) == len(y) == 5
        counter[group, key] = dict(a=st.median(v[0] for v in x), b=st.median(v[0] for v in y),
            ai=st.median(v[1] for v in x), bi=st.median(v[1] for v in y),
            delta_cycles=100 * (st.median(b[0] / a[0] for a, b in zip(x, y)) - 1))
elif not a.partial:
    raise RuntimeError('The 58-case counter series has not completed')

rows = []
hashes = {}
for folder in ['amd-primary', 'amd-matrix', 'amd-wide-check']:
    for path in sorted((a.data / folder).glob('*.json')):
        d = json.loads(path.read_text())
        if 'sides' not in d or 'cases' not in d:
            continue
        assert len(d['cases']) == 1
        cfg = d['config']
        assert [cfg[k] for k in ['rounds', 'samples', 'target_ms', 'warmup_ms']] == [1, 10, 1000, 3000]
        key, case = next(iter(d['cases'].items()))
        cc = 'clang21' if 'clang21' in d['sides']['A']['name'] else 'gcc15'
        aa = d['sides']['A']['name'] == d['sides']['B']['name']
        for side in ['A', 'B']:
            meta = d['sides'][side]['build']
            expected = 'cf1b5771a76a81b455a8677446daf9c46e1781be' if side == 'A' or aa else '8d7babbc364ffcf28dac9777ce807edc9adbb534'
            assert meta['commit'] == expected and not meta['debug'] and not meta['snapshot']
        x, y = [case['sides'][s] for s in ['A', 'B']]
        assert x['input_hash'] == y['input_hash'] and x['output_hash'] == y['output_hash']
        am, bm = [st.median(v['rounds'][0]) - st.median(v['loop_ns']) for v in [x, y]]
        samples = [[s - st.median(v['loop_ns']) for s in v['rounds'][0]] for v in [x, y]]
        log = path.with_suffix('.log')
        timeout = 'measuring anyway' in log.read_text()
        record = dict(source=str(path.relative_to(a.data)), compiler=cc, case=key, aa=aa,
            phase=folder, bytes=case['input_len'], master_ns=am, compact_ns=bm,
            delta_time=100 * (bm / am - 1), min_ns=[min(s) for s in samples], max_ns=[max(s) for s in samples],
            idle_timeout=timeout, noisy=timeout or any(max(s) / min(s) > 1.10 for s in samples),
            counters=None if aa else counter.get((cc, key)))
        rows.append(record)
        hashes[str(path.relative_to(a.data))] = hashlib.sha256(path.read_bytes()).hexdigest()
assert len(rows) == 52 and sum(not r['aa'] for r in rows) == 43
keys = {(r['compiler'], r['case']) for r in rows if not r['aa']}
assert len(keys) == 43

def pct(v):
    return f'{v:+.2f}%'

def label(case):
    api, kind, length = case['name'].split('/')
    return {'absent': 'Absent in ordinary text', 'early': 'Match at offset 0',
        'late': 'Match at the last position', 'prefix': 'Repeated prefix, no match',
        'repeated': api + ', repeated matches'}[kind]

doc = '''# Search-shape controls

Full PHP CLI builds: compact `8d7babbc364` versus master `cf1b5771a76`.
AMD Ryzen 9 5950X, CPU 15, performance governor, turbo on; the core is not reserved.
All inputs are 4096 bytes. Times are microseconds per complete PHP operation,
with empty-loop subtraction. All changes are relative to master; negative is lower cost.

The main elapsed matrix has 21 inputs per compiler; a separate GCC 15 check
adds a 64-byte repeated-prefix search and same-input A/A. The counter matrix
has 58 inputs. Ordinary absent, early, late and
repeated-prefix searches use needles of 9, 16 and 31 bytes. Early-match controls
also use 32, 64 and 256 bytes. `substr_count()` and `str_replace()` repeat searches
for 9/16/31-byte needles. These repeated fixtures contain 86/75/58 matches.

All four single-search shapes use `strpos()`. The ordinary ASCII filler contains order/payment/delivery messages. Early matches
start at zero; late matches end at the input boundary. Repeated-prefix inputs are
`a` repeated 4096 times, searched for `a` repeated `m-1` times followed by `b`.

Each elapsed comparison has one paired round: at least 3 seconds warmup and ten
approximately one-second samples per build. The two measurement batches each
have before/after identical-binary A/A on the 16-byte repeated-prefix input.
The additional 64-byte check has its own same-input A/A. Counters are a separate
five-pass series, with Clang 21 identical-binary controls before and after.
Small movements are descriptive; they do not establish a statistical speedup.
Cycle deltas are the median of five paired compact/master ratios; instruction
deltas compare median counts.

The <32 cutoff limits the optimization to short tokens; it is not the byte-table
capacity limit. All shifts fit in a byte up to needle length 254. These
measurements do not establish that 32 is an optimal cutoff.

'''
for cc, title in [('clang21', 'Clang 21.1'), ('gcc15', 'GCC 15.2')]:
    values = {r['case'].split(' @ ')[0]: r for r in rows if r['compiler'] == cc and not r['aa']}
    envelope = max(abs(r['delta_time']) for r in rows if r['compiler'] == cc and r['aa'])
    doc += f'## {title}\n\nLargest observed elapsed A/A: {envelope:.2f}%.\n\n'
    doc += '| Search | Needle B | master µs | compact µs | Time Δ | Cycles Δ | Instr. Δ |\n|---|--:|--:|--:|--:|--:|--:|\n'
    for name in selected:
        r = values[name]; case = by_name[name]; c = r['counters']
        dc = pct(c['delta_cycles']) if c else 'pending'
        di = pct(100 * (c['bi'] / c['ai'] - 1)) if c else 'pending'
        doc += f"| {label(case)} | {case['needle_bytes']} | {r['master_ns']/1000:.4f} | {r['compact_ns']/1000:.4f} | {pct(r['delta_time'])} | {dc} | {di} |\n"
    doc += '\n'
wide = next(r for r in rows if r['phase'] == 'amd-wide-check' and not r['aa'])
wide_aa = next(r for r in rows if r['phase'] == 'amd-wide-check' and r['aa'])
c = wide['counters']
doc += '## Synthetic repeated-prefix regression\n\n'
doc += 'A separate elapsed check follows the 58-case counter sweep. It uses `strpos(str_repeat("a", 4096), str_repeat("a", 63) . "b")`, returning `false`.\n\n'
doc += '| Compiler | Needle B | master µs | compact µs | Time Δ | Cycles Δ | Instr. Δ |\n|---|--:|--:|--:|--:|--:|--:|\n'
doc += f"| GCC 15.2 | 64 | {wide['master_ns']/1000:.4f} | {wide['compact_ns']/1000:.4f} | {pct(wide['delta_time'])} | {pct(c['delta_cycles'])} | {pct(100*(c['bi']/c['ai']-1))} |\n\n"
doc += f"Same-input identical-binary A/A: {pct(wide_aa['delta_time'])}. This needle uses the existing wide table; the byte table is not involved. A separate three-pass `bench why` run records about 1 versus 2019 branch misses per call, with nearly unchanged instruction counts. The loop addresses differ. The precise placement mechanism has not been isolated.\n\n"
doc += 'This input is deliberately constructed to produce repeated long partial matches. The patch retains Sunday’s existing quadratic worst case. Keep this regression separate from the ordinary-text results when assessing the trade-off.\n\n'
doc += '## Elapsed A/A\n\nAll main-batch A/A rows use the 16-byte repeated prefix; amd-wide-check uses 64 bytes.\n\n| Batch | Compiler | Position | First µs | Second µs | Time Δ |\n|---|---|---|--:|--:|--:|\n'
for r in rows:
    if r['aa']:
        doc += f"| {r['phase']} | {r['compiler']} | {'before' if 'before' in r['source'] else 'after'} | {r['master_ns']/1000:.4f} | {r['compact_ns']/1000:.4f} | {pct(r['delta_time'])} |\n"
doc += '''
## Coverage and correctness

The counter matrix covers four search shapes at byte lengths 8, 9, 16, 24, 31,
32, 33, 48, 64, 128, 254, 255 and 256, plus six repeated-operation cases: 58 in
total. All 58 return independent Python-computed expected values in both compiler
pairs and the full PHP ASan/UBSan build. Source commits and executable hashes are
checked before measurement. There are no Intel elapsed results in this dataset.

## Generated code

In the captured Clang 21 PHP binaries the inner candidate-comparison loop is
byte-identical: 19 bytes, six instructions. Table preparation, shift loads, stack
frame sizes and code addresses differ. The identical inner loop does not establish
a unique cause for small timing movements or predict other compiler versions.
'''
noisy = [r['source'] for r in rows if r['noisy']]
if noisy:
    doc += '\nRows with >10% sample range or an idle timeout are inconclusive: ' + ', '.join(noisy) + '.\n'
doc += '\n[All 58 counter cases and ranges](search-counters.md) · [Unrounded values](search-metrics.json) · [Native data and measurement scripts](data/search-controls.tar.gz) · [Exact inputs and expectations](search-cases.json) · [Suite](search-suite.php) · [Raw hashes](search-manifest.json) · [Clang 21 disassembly](search-codegen.json).\n\nTo rerun an individual case, use `bench run search-suite.php` with matched master/compact builds, the case filter, `--rounds 1 --samples 10 --target-ms 1000 --warmup-ms 3000`. Run one case at a time. Use `bench compare` with `--passes 5 --target-ms 50` for counters. CPU and build-directory selection follow [the reproduction instructions](reproduce.md).\n'
(a.out / 'search-controls.md').write_text(doc)
(a.out / 'search-metrics.json').write_text(json.dumps(rows, indent=2) + '\n')
(a.out / 'search-manifest.json').write_text(json.dumps(dict(elapsed_pairs=len(rows), ab_pairs=43,
    timed_cases=selected, counter_cases=58, raw_sha256=hashes), indent=2) + '\n')
print('Rendered 43 A/B and 9 A/A elapsed records; noisy:', len(noisy), 'complete counters:', bool(counter))
