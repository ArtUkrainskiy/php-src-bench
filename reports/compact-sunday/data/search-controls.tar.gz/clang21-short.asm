
/tmp/php-compact-sunday-20261031/builds/compact-head-clang21/sapi/cli/php:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000072b4f0 <zend_memnstr_sunday_short>:
  72b4f0:	push   %rbx
  72b4f1:	sub    $0x110,%rsp
  72b4f8:	mov    %fs:0x28,%rax
  72b501:	mov    %rax,0x108(%rsp)
  72b509:	mov    %rcx,%rax
  72b50c:	sub    %rdi,%rax
  72b50f:	lea    -0x1(%rdx),%r8
  72b513:	cmp    %rax,%r8
  72b516:	jae    72b5bb <zend_memnstr_sunday_short+0xcb>
  72b51c:	lea    0x1(%rdx),%eax
  72b51f:	movzbl %al,%eax
  72b522:	movd   %eax,%xmm0
  72b526:	punpcklbw %xmm0,%xmm0
  72b52a:	pshuflw $0x0,%xmm0,%xmm0
  72b52f:	pshufd $0x44,%xmm0,%xmm0
  72b534:	movdqa %xmm0,0xf0(%rsp)
  72b53d:	movdqa %xmm0,0xe0(%rsp)
  72b546:	movdqa %xmm0,0xd0(%rsp)
  72b54f:	movdqa %xmm0,0xc0(%rsp)
  72b558:	movdqa %xmm0,0xb0(%rsp)
  72b561:	movdqa %xmm0,0xa0(%rsp)
  72b56a:	movdqa %xmm0,0x90(%rsp)
  72b573:	movdqa %xmm0,0x80(%rsp)
  72b57c:	movdqa %xmm0,0x70(%rsp)
  72b582:	movdqa %xmm0,0x60(%rsp)
  72b588:	movdqa %xmm0,0x50(%rsp)
  72b58e:	movdqa %xmm0,0x40(%rsp)
  72b594:	movdqa %xmm0,0x30(%rsp)
  72b59a:	movdqa %xmm0,0x20(%rsp)
  72b5a0:	movdqa %xmm0,0x10(%rsp)
  72b5a6:	movdqa %xmm0,(%rsp)
  72b5ab:	mov    %edx,%eax
  72b5ad:	and    $0x3,%eax
  72b5b0:	cmp    $0x3,%r8
  72b5b4:	jae    72b5c2 <zend_memnstr_sunday_short+0xd2>
  72b5b6:	xor    %r8d,%r8d
  72b5b9:	jmp    72b610 <zend_memnstr_sunday_short+0x120>
  72b5bb:	xor    %eax,%eax
  72b5bd:	jmp    72b6a1 <zend_memnstr_sunday_short+0x1b1>
  72b5c2:	mov    %edx,%r9d
  72b5c5:	and    $0x1c,%r9d
  72b5c9:	xor    %r8d,%r8d
  72b5cc:	mov    %edx,%r10d
  72b5cf:	nop
  72b5d0:	movzbl (%rsi,%r8,1),%r11d
  72b5d5:	mov    %r10b,(%rsp,%r11,1)
  72b5d9:	lea    -0x1(%r10),%r11d
  72b5dd:	movzbl 0x1(%rsi,%r8,1),%ebx
  72b5e3:	mov    %r11b,(%rsp,%rbx,1)
  72b5e7:	lea    -0x2(%r10),%r11d
  72b5eb:	movzbl 0x2(%rsi,%r8,1),%ebx
  72b5f1:	mov    %r11b,(%rsp,%rbx,1)
  72b5f5:	lea    -0x3(%r10),%r11d
  72b5f9:	movzbl 0x3(%rsi,%r8,1),%ebx
  72b5ff:	mov    %r11b,(%rsp,%rbx,1)
  72b603:	add    $0x4,%r8
  72b607:	add    $0xfc,%r10b
  72b60b:	cmp    %r8,%r9
  72b60e:	jne    72b5d0 <zend_memnstr_sunday_short+0xe0>
  72b610:	test   %rax,%rax
  72b613:	je     72b644 <zend_memnstr_sunday_short+0x154>
  72b615:	lea    (%rsi,%r8,1),%r9
  72b619:	mov    %edx,%r10d
  72b61c:	sub    %r8b,%r10b
  72b61f:	xor    %r8d,%r8d
  72b622:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72b630:	movzbl (%r9,%r8,1),%r11d
  72b635:	mov    %r10b,(%rsp,%r11,1)
  72b639:	inc    %r8
  72b63c:	dec    %r10b
  72b63f:	cmp    %r8,%rax
  72b642:	jne    72b630 <zend_memnstr_sunday_short+0x140>
  72b644:	sub    %rdx,%rcx
  72b647:	xor    %eax,%eax
  72b649:	cmp    %rcx,%rdi
  72b64c:	ja     72b6a1 <zend_memnstr_sunday_short+0x1b1>
  72b64e:	xor    %r8d,%r8d
  72b651:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72b660:	movzbl (%rsi,%r8,1),%r9d
  72b665:	cmp    (%rdi,%r8,1),%r9b
  72b669:	jne    72b680 <zend_memnstr_sunday_short+0x190>
  72b66b:	inc    %r8
  72b66e:	cmp    %r8,%rdx
  72b671:	jne    72b660 <zend_memnstr_sunday_short+0x170>
  72b673:	jmp    72b69e <zend_memnstr_sunday_short+0x1ae>
  72b675:	data16 cs nopw 0x0(%rax,%rax,1)
  72b680:	cmp    %r8,%rdx
  72b683:	je     72b69e <zend_memnstr_sunday_short+0x1ae>
  72b685:	cmp    %rcx,%rdi
  72b688:	je     72b6a1 <zend_memnstr_sunday_short+0x1b1>
  72b68a:	movzbl (%rdi,%rdx,1),%r8d
  72b68f:	movzbl (%rsp,%r8,1),%r8d
  72b694:	add    %r8,%rdi
  72b697:	cmp    %rcx,%rdi
  72b69a:	jbe    72b64e <zend_memnstr_sunday_short+0x15e>
  72b69c:	jmp    72b6a1 <zend_memnstr_sunday_short+0x1b1>
  72b69e:	mov    %rdi,%rax
  72b6a1:	mov    %fs:0x28,%rcx
  72b6aa:	cmp    0x108(%rsp),%rcx
  72b6b2:	jne    72b6bd <zend_memnstr_sunday_short+0x1cd>
  72b6b4:	add    $0x110,%rsp
  72b6bb:	pop    %rbx
  72b6bc:	ret
  72b6bd:	call   200cd0 <__stack_chk_fail@plt>

Disassembly of section .remap_stub:

Disassembly of section .fini:
