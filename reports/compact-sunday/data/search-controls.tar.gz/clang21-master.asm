
/tmp/php-compact-sunday-20261031/builds/compact-base-clang21/sapi/cli/php:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000072b4e0 <zend_memnstr_ex>:
  72b4e0:	push   %rbx
  72b4e1:	sub    $0x410,%rsp
  72b4e8:	mov    %fs:0x28,%rax
  72b4f1:	mov    %rax,0x408(%rsp)
  72b4f9:	mov    %rcx,%rax
  72b4fc:	sub    %rdi,%rax
  72b4ff:	lea    -0x1(%rdx),%r8
  72b503:	cmp    %rax,%r8
  72b506:	jae    72b74f <zend_memnstr_ex+0x26f>
  72b50c:	lea    0x1(%rdx),%eax
  72b50f:	movd   %eax,%xmm0
  72b513:	pshufd $0x0,%xmm0,%xmm0
  72b518:	movdqa %xmm0,(%rsp)
  72b51d:	movdqa %xmm0,0x10(%rsp)
  72b523:	movdqa %xmm0,0x20(%rsp)
  72b529:	movdqa %xmm0,0x30(%rsp)
  72b52f:	movdqa %xmm0,0x40(%rsp)
  72b535:	movdqa %xmm0,0x50(%rsp)
  72b53b:	movdqa %xmm0,0x60(%rsp)
  72b541:	movdqa %xmm0,0x70(%rsp)
  72b547:	movdqa %xmm0,0x80(%rsp)
  72b550:	movdqa %xmm0,0x90(%rsp)
  72b559:	movdqa %xmm0,0xa0(%rsp)
  72b562:	movdqa %xmm0,0xb0(%rsp)
  72b56b:	movdqa %xmm0,0xc0(%rsp)
  72b574:	movdqa %xmm0,0xd0(%rsp)
  72b57d:	movdqa %xmm0,0xe0(%rsp)
  72b586:	movdqa %xmm0,0xf0(%rsp)
  72b58f:	movdqa %xmm0,0x100(%rsp)
  72b598:	movdqa %xmm0,0x110(%rsp)
  72b5a1:	movdqa %xmm0,0x120(%rsp)
  72b5aa:	movdqa %xmm0,0x130(%rsp)
  72b5b3:	movdqa %xmm0,0x140(%rsp)
  72b5bc:	movdqa %xmm0,0x150(%rsp)
  72b5c5:	movdqa %xmm0,0x160(%rsp)
  72b5ce:	movdqa %xmm0,0x170(%rsp)
  72b5d7:	movdqa %xmm0,0x180(%rsp)
  72b5e0:	movdqa %xmm0,0x190(%rsp)
  72b5e9:	movdqa %xmm0,0x1a0(%rsp)
  72b5f2:	movdqa %xmm0,0x1b0(%rsp)
  72b5fb:	movdqa %xmm0,0x1c0(%rsp)
  72b604:	movdqa %xmm0,0x1d0(%rsp)
  72b60d:	movdqa %xmm0,0x1e0(%rsp)
  72b616:	movdqa %xmm0,0x1f0(%rsp)
  72b61f:	movdqa %xmm0,0x200(%rsp)
  72b628:	movdqa %xmm0,0x210(%rsp)
  72b631:	movdqa %xmm0,0x220(%rsp)
  72b63a:	movdqa %xmm0,0x230(%rsp)
  72b643:	movdqa %xmm0,0x240(%rsp)
  72b64c:	movdqa %xmm0,0x250(%rsp)
  72b655:	movdqa %xmm0,0x260(%rsp)
  72b65e:	movdqa %xmm0,0x270(%rsp)
  72b667:	movdqa %xmm0,0x280(%rsp)
  72b670:	movdqa %xmm0,0x290(%rsp)
  72b679:	movdqa %xmm0,0x2a0(%rsp)
  72b682:	movdqa %xmm0,0x2b0(%rsp)
  72b68b:	movdqa %xmm0,0x2c0(%rsp)
  72b694:	movdqa %xmm0,0x2d0(%rsp)
  72b69d:	movdqa %xmm0,0x2e0(%rsp)
  72b6a6:	movdqa %xmm0,0x2f0(%rsp)
  72b6af:	movdqa %xmm0,0x300(%rsp)
  72b6b8:	movdqa %xmm0,0x310(%rsp)
  72b6c1:	movdqa %xmm0,0x320(%rsp)
  72b6ca:	movdqa %xmm0,0x330(%rsp)
  72b6d3:	movdqa %xmm0,0x340(%rsp)
  72b6dc:	movdqa %xmm0,0x350(%rsp)
  72b6e5:	movdqa %xmm0,0x360(%rsp)
  72b6ee:	movdqa %xmm0,0x370(%rsp)
  72b6f7:	movdqa %xmm0,0x380(%rsp)
  72b700:	movdqa %xmm0,0x390(%rsp)
  72b709:	movdqa %xmm0,0x3a0(%rsp)
  72b712:	movdqa %xmm0,0x3b0(%rsp)
  72b71b:	movdqa %xmm0,0x3c0(%rsp)
  72b724:	movdqa %xmm0,0x3d0(%rsp)
  72b72d:	movdqa %xmm0,0x3e0(%rsp)
  72b736:	movdqa %xmm0,0x3f0(%rsp)
  72b73f:	mov    %edx,%eax
  72b741:	and    $0x3,%eax
  72b744:	cmp    $0x3,%r8
  72b748:	jae    72b756 <zend_memnstr_ex+0x276>
  72b74a:	xor    %r8d,%r8d
  72b74d:	jmp    72b7b0 <zend_memnstr_ex+0x2d0>
  72b74f:	xor    %eax,%eax
  72b751:	jmp    72b840 <zend_memnstr_ex+0x360>
  72b756:	mov    %rdx,%r9
  72b759:	and    $0xfffffffffffffffc,%r9
  72b75d:	xor    %r8d,%r8d
  72b760:	mov    %edx,%r10d
  72b763:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72b770:	movzbl (%rsi,%r8,1),%r11d
  72b775:	mov    %r10d,(%rsp,%r11,4)
  72b779:	lea    -0x1(%r10),%r11d
  72b77d:	movzbl 0x1(%rsi,%r8,1),%ebx
  72b783:	mov    %r11d,(%rsp,%rbx,4)
  72b787:	lea    -0x2(%r10),%r11d
  72b78b:	movzbl 0x2(%rsi,%r8,1),%ebx
  72b791:	mov    %r11d,(%rsp,%rbx,4)
  72b795:	lea    -0x3(%r10),%r11d
  72b799:	movzbl 0x3(%rsi,%r8,1),%ebx
  72b79f:	mov    %r11d,(%rsp,%rbx,4)
  72b7a3:	add    $0x4,%r8
  72b7a7:	add    $0xfffffffc,%r10d
  72b7ab:	cmp    %r8,%r9
  72b7ae:	jne    72b770 <zend_memnstr_ex+0x290>
  72b7b0:	test   %rax,%rax
  72b7b3:	je     72b7e4 <zend_memnstr_ex+0x304>
  72b7b5:	lea    (%rsi,%r8,1),%r9
  72b7b9:	mov    %edx,%r10d
  72b7bc:	sub    %r8d,%r10d
  72b7bf:	xor    %r8d,%r8d
  72b7c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72b7d0:	movzbl (%r9,%r8,1),%r11d
  72b7d5:	mov    %r10d,(%rsp,%r11,4)
  72b7d9:	inc    %r8
  72b7dc:	dec    %r10d
  72b7df:	cmp    %r8,%rax
  72b7e2:	jne    72b7d0 <zend_memnstr_ex+0x2f0>
  72b7e4:	sub    %rdx,%rcx
  72b7e7:	xor    %eax,%eax
  72b7e9:	cmp    %rcx,%rdi
  72b7ec:	ja     72b840 <zend_memnstr_ex+0x360>
  72b7ee:	xor    %r8d,%r8d
  72b7f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72b800:	movzbl (%rsi,%r8,1),%r9d
  72b805:	cmp    (%rdi,%r8,1),%r9b
  72b809:	jne    72b820 <zend_memnstr_ex+0x340>
  72b80b:	inc    %r8
  72b80e:	cmp    %r8,%rdx
  72b811:	jne    72b800 <zend_memnstr_ex+0x320>
  72b813:	jmp    72b83d <zend_memnstr_ex+0x35d>
  72b815:	data16 cs nopw 0x0(%rax,%rax,1)
  72b820:	cmp    %r8,%rdx
  72b823:	je     72b83d <zend_memnstr_ex+0x35d>
  72b825:	cmp    %rcx,%rdi
  72b828:	je     72b840 <zend_memnstr_ex+0x360>
  72b82a:	movzbl (%rdi,%rdx,1),%r8d
  72b82f:	mov    (%rsp,%r8,4),%r8d
  72b833:	add    %r8,%rdi
  72b836:	cmp    %rcx,%rdi
  72b839:	jbe    72b7ee <zend_memnstr_ex+0x30e>
  72b83b:	jmp    72b840 <zend_memnstr_ex+0x360>
  72b83d:	mov    %rdi,%rax
  72b840:	mov    %fs:0x28,%rcx
  72b849:	cmp    0x408(%rsp),%rcx
  72b851:	jne    72b85c <zend_memnstr_ex+0x37c>
  72b853:	add    $0x410,%rsp
  72b85a:	pop    %rbx
  72b85b:	ret
  72b85c:	call   200cd0 <__stack_chk_fail@plt>

Disassembly of section .remap_stub:

Disassembly of section .fini:
