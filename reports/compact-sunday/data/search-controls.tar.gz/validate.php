<?php
$root = __DIR__;
$suite = require $root . '/suite.php';
$manifest = json_decode(file_get_contents($root . '/cases.json'), true, 512, JSON_THROW_ON_ERROR);
$checked = 0;
foreach ($manifest['cases'] as $case) {
    $s = $suite['inputs'][$case['input']];
    if (strlen($s) !== $case['input_bytes'] || hash('sha256', $s) !== $case['input_sha256']) {
        throw new RuntimeException('Input mismatch: ' . $case['name']);
    }
    $definition = $suite['cases'][$case['name']];
    if ($definition['code'] !== $case['code'] || $definition['inputs'] !== [$case['input']]) {
        throw new RuntimeException('Suite definition mismatch: ' . $case['name']);
    }
    $got = eval('return ' . $definition['code'] . ';');
    if ($got !== $case['expected']) {
        throw new RuntimeException('Output mismatch: ' . $case['name']);
    }
    $checked++;
}
echo "checked $checked; all outputs match independent expectations\n";
